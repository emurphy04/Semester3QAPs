-- for waiters to send the orders off to the kitchen

create table custOrders(
	orderID int,
	orderDate date,
	orderItems text,
	orderPrice text,
	serverID text
);

-- for kitchen to complete the order

create table kitchenOrders(
	isComplete bool,
	orderID int,
	orderItems text,
	chefID text
)